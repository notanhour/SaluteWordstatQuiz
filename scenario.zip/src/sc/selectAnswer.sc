patterns:
    $LeftWord = (лево|левой|левый|слева|первый|первый вариант|первая|первое|один|раз)
    $RightWord = (право|правой|правый|справа|второй|второй вариант|вторая|второе|два)

theme: /

    state: SelectLeft
        q!: $LeftWord
        script:
            log('selectLeft: ' + JSON.stringify($context))
            selectLeft($context)
        random:
            a: Левый вариант.

    state: SelectLeftWithPrefix
        q!: (~выбери|~нажми|~скажи|~хочу) $LeftWord
        script:
            log('selectLeftWithPrefix: ' + JSON.stringify($context))
            selectLeft($context)
        random:
            a: Левый вариант.

    state: SelectRight
        q!: $RightWord
        script:
            log('selectRight: ' + JSON.stringify($context))
            selectRight($context)
        random:
            a: Правый вариант.

    state: SelectRightWithPrefix
        q!: (~выбери|~нажми|~скажи|~хочу) $RightWord
        script:
            log('selectRightWithPrefix: ' + JSON.stringify($context))
            selectRight($context)
        random:
            a: Правый вариант.