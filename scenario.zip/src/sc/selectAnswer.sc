patterns:
    $LeftWord = (лево|левой|левый|левая|слева|первый|первая|первое|первого|один|раз)
    $RightWord = (право|правой|правый|правая|справа|второй|вторая|второе|второго|два)
    $AnswerVerb = (выбери|выбрать|выбираю|хочу|беру|ставлю|нажми|нажать|скажи|голосую|отвечаю|мой ответ|мой выбор)
    $AnswerNoun = (ответ|вариант|выбор|карточка|карточку)

theme: /

    state: SelectLeft
        q!: $LeftWord [$AnswerNoun]
        script:
            log('selectLeft: ' + JSON.stringify($context))
            selectLeft($context)
        random:
            a: Левый вариант.

    state: SelectLeftWithVerb
        q!: $AnswerVerb $LeftWord [$AnswerNoun]
        script:
            log('selectLeftWithVerb: ' + JSON.stringify($context))
            selectLeft($context)
        random:
            a: Левый вариант.

    state: SelectRight
        q!: $RightWord [$AnswerNoun]
        script:
            log('selectRight: ' + JSON.stringify($context))
            selectRight($context)
        random:
            a: Правый вариант.

    state: SelectRightWithVerb
        q!: $AnswerVerb $RightWord [$AnswerNoun]
        script:
            log('selectRightWithVerb: ' + JSON.stringify($context))
            selectRight($context)
        random:
            a: Правый вариант.