patterns:
    $LeftWord = (лево|левой|левый|слева|первый|первый вариант|первая|первое|первого|один|раз)
    $RightWord = (право|правой|правый|справа|второй|второй вариант|вторая|второе|второго|два)
    $AnswerVerb = (выбери|выбрать|выбираю|хочу|беру|ставлю|нажми|нажать|скажи|голосую|отвечаю|мой ответ|мой выбор)

theme: /

    state: SelectLeft
        q!: $LeftWord
        script:
            log('selectLeft: ' + JSON.stringify($context))
            selectLeft($context)
        random:
            a: Левый вариант.

    state: SelectLeftWithVerb
        q!: $AnswerVerb $LeftWord
        script:
            log('selectLeftWithVerb: ' + JSON.stringify($context))
            selectLeft($context)
        random:
            a: Левый вариант.

    state: SelectRight
        q!: $RightWord
        script:
            log('selectRight: ' + JSON.stringify($context))
            selectRight($context)
        random:
            a: Правый вариант.

    state: SelectRightWithVerb
        q!: $AnswerVerb $RightWord
        script:
            log('selectRightWithVerb: ' + JSON.stringify($context))
            selectRight($context)
        random:
            a: Правый вариант.