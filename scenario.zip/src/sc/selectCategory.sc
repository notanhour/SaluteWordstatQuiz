patterns:
    $Category = (страны|еда|авто|книги|кино|музыка|спорт|игры|люди|технологии|бренды|мемы)
    $CategoryHint = (категорию|раздел|тему|секцию|направление)
    $CategoryVerb = (выбери|выбрать|открой|открыть|запусти|запустить|начни|начать|перейди|перейти|покажи|показать|включи|включить|хочу|давай|поиграем|интересует)

theme: /

    state: SelectCategory
        q!: $CategoryVerb [$CategoryHint]
            $Category::category
        script:
            log('selectCategory: ' + JSON.stringify($context))
            selectCategory($parseTree._category, $context)
        random:
            a: Хорошо.
            a: Ок.

    state: SelectCategoryShort
        q!: $Category::category
        script:
            log('selectCategoryShort: ' + JSON.stringify($context))
            selectCategory($parseTree._category, $context)
        random:
            a: Хорошо.
            a: Ок.