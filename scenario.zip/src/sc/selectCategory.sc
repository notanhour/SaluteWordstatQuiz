patterns:
    $Category = (еда|фильмы|игры|музыка|спорт|путешествия|технологии|авто)
    $CategoryHint = (категорию|раздел|тему)

theme: /

    state: SelectCategory
        q!: (~выбери|~открой|~покажи|~начни|~запусти|~перейди|~хочу) [$CategoryHint]
            $Category::category
        script:
            log('selectCategory: ' + JSON.stringify($context))
            selectCategory($parseTree._category, $context)
        random:
            a: Хорошо.
            a: Ок.

    state: SelectCategoryShort
        q!: $Category::category
        script:
            log('selectCategoryShort: ' + JSON.stringify($context))
            selectCategory($parseTree._category, $context)
        random:
            a: Хорошо.
            a: Ок.