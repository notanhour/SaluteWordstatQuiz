patterns:
    $MenuPhrase = (в меню|главное меню|на главную|выбор категории|выбор темы|смена категории|смена темы|к темам|к категориям)
    $MenuVerb = (вернись|верни|перейди|перейти|иди|открой|открыть|покажи|показать|сменить|смени|выбери|выбрать|хочу)
    $CategoryNoun = (категорию|категории|тему|темы|раздел|разделы)
    $CategoryVerb = (выбрать|выбери|выбор|сменить|смени|смена)

theme: /

    state: ВернутьсяВМеню
        q!: $MenuPhrase
        script:
            log('backToMenu: ' + JSON.stringify($context))
            backToMenu($context)
        random:
            a: Возвращаюсь в меню.
            a: Хорошо, идём в меню.

    state: ВернутьсяВМенюWithVerb
        q!: $MenuVerb [$MenuPhrase]
        script:
            log('backToMenuWithVerb: ' + JSON.stringify($context))
            backToMenu($context)
        random:
            a: Возвращаюсь в меню.
            a: Хорошо, идём в меню.

    state: ВернутьсяВМенюCategory
        q!: $CategoryVerb $CategoryNoun
        script:
            log('backToMenuCategory: ' + JSON.stringify($context))
            backToMenu($context)
        random:
            a: Возвращаюсь в меню.
            a: Хорошо, идём в меню.