function selectCategory(category, context) {
    var mapping = {
        'страны': 'countries',
        'еда': 'food',
        'авто': 'auto',
        'книги': 'books',
        'кино': 'movies',
        'музыка': 'music',
        'спорт': 'sport',
        'игры': 'games',
        'люди': 'people',
        'технологии': 'tech',
        'бренды': 'brands',
        'мемы': 'memes'
    };
    var key = category && category.trim().toLowerCase();
    var categoryId = mapping[key] || key;
    addAction({
        type: "select_category",
        categoryId: categoryId
    }, context);
}

function selectLeft(context) {
    addAction({
        type: "select_left"
    }, context);
}

function selectRight(context) {
    addAction({
        type: "select_right"
    }, context);
}

function backToMenu(context) {
    addAction({
        type: "back_to_menu"
    }, context);
}

function nextQuestion(context) {
    addAction({
        type: "next_question"
    }, context);
}